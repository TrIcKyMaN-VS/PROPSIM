using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;

namespace NinjaTrader.Custom.AddOns.PropSim
{
    public class PropSimSyncEngine
    {
        private readonly PropSimApiClient _apiClient;
        
        // Dictionary to track Average Entry Price and Quantity for each Account-Instrument pair
        // Key: "AccountName-InstrumentName"
        private readonly Dictionary<string, PositionState> _positions = new Dictionary<string, PositionState>();
        
        // Queue for pending trades
        private readonly List<PropSimTradePayload> _pendingQueue = new List<PropSimTradePayload>();
        private readonly string _queueFilePath;
        private readonly object _queueLock = new object();

        public PropSimSyncEngine(string token)
        {
            _apiClient = new PropSimApiClient(token);
            _queueFilePath = Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "propsim_pending_trades.txt");
            LoadQueue();
        }

        public void SyncAccounts(IEnumerable<string> accounts)
        {
            _ = _apiClient.SyncAccountsAsync(accounts);
        }

        public void SendHeartbeat()
        {
            _ = _apiClient.SendHeartbeatAsync();
            FlushQueueAsync();
        }

        public void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
            string key = $"{execution.Account.Name}-{execution.Instrument.FullName}";

            if (!_positions.ContainsKey(key))
            {
                _positions[key] = new PositionState { MarketPosition = MarketPosition.Flat, Quantity = 0 };
            }

            var state = _positions[key];
            
            // If the account's current position is Flat, or if this execution ADDS to the current position direction
            if (state.MarketPosition == MarketPosition.Flat)
            {
                // New position started
                state.MarketPosition = marketPosition;
                state.Quantity = quantity;
                state.AverageEntryPrice = price;
                state.EntryTime = time;
                state.Direction = marketPosition == MarketPosition.Long ? "long" : "short";
            }
            else if (state.MarketPosition == marketPosition)
            {
                // Adding to existing position
                double totalCost = (state.AverageEntryPrice * state.Quantity) + (price * quantity);
                state.Quantity += quantity;
                state.AverageEntryPrice = totalCost / state.Quantity;
            }
            else
            {
                // This execution is in the OPPOSITE direction (it's reducing the position or reversing)
                int closedQuantity = Math.Min(state.Quantity, quantity);
                
                if (closedQuantity > 0)
                {
                    // Calculate exact PnL for the closed portion
                    double multiplier = state.MarketPosition == MarketPosition.Long ? 1 : -1;
                    double pnl = (price - state.AverageEntryPrice) * closedQuantity * execution.Instrument.MasterInstrument.PointValue * multiplier;

                    var payload = new PropSimTradePayload
                    {
                        ProviderTradeId = executionId,
                        AccountName = execution.Account.Name,
                        Instrument = execution.Instrument.FullName,
                        Direction = state.Direction,
                        EntryPrice = state.AverageEntryPrice,
                        ExitPrice = price,
                        Contracts = closedQuantity,
                        PnL = pnl,
                        EntryTime = state.EntryTime,
                        ExitTime = time
                    };

                    QueueTrade(payload);

                    // Reduce tracked position
                    state.Quantity -= closedQuantity;
                }

                // If the execution quantity was GREATER than our tracked position, it's a reversal
                int remainingQuantity = quantity - closedQuantity;
                if (remainingQuantity > 0)
                {
                    state.MarketPosition = marketPosition;
                    state.Quantity = remainingQuantity;
                    state.AverageEntryPrice = price;
                    state.EntryTime = time;
                    state.Direction = marketPosition == MarketPosition.Long ? "long" : "short";
                }
                else if (state.Quantity == 0)
                {
                    // Fully flat
                    state.MarketPosition = MarketPosition.Flat;
                }
            }
        }

        private void QueueTrade(PropSimTradePayload payload)
        {
            lock (_queueLock)
            {
                _pendingQueue.Add(payload);
                SaveQueue();
            }
            FlushQueueAsync();
        }

        private async void FlushQueueAsync()
        {
            List<PropSimTradePayload> batch;
            lock (_queueLock)
            {
                if (_pendingQueue.Count == 0) return;
                batch = _pendingQueue.ToList();
            }

            bool success = await _apiClient.SyncTradesBulkAsync(batch);
            
            if (success)
            {
                lock (_queueLock)
                {
                    // Remove the trades that were successfully sent
                    var sentIds = new HashSet<string>(batch.Select(b => b.ProviderTradeId));
                    _pendingQueue.RemoveAll(t => sentIds.Contains(t.ProviderTradeId));
                    SaveQueue();
                }
            }
        }

        private void SaveQueue()
        {
            try
            {
                var lines = _pendingQueue.Select(t => $"{t.ProviderTradeId}|{t.AccountName}|{t.Instrument}|{t.Direction}|{t.EntryPrice}|{t.ExitPrice}|{t.Contracts}|{t.PnL}|{t.EntryTime.Ticks}|{t.ExitTime.Ticks}");
                File.WriteAllLines(_queueFilePath, lines);
            }
            catch { }
        }

        private void LoadQueue()
        {
            try
            {
                if (File.Exists(_queueFilePath))
                {
                    var lines = File.ReadAllLines(_queueFilePath);
                    foreach (var line in lines)
                    {
                        var parts = line.Split('|');
                        if (parts.Length == 10)
                        {
                            _pendingQueue.Add(new PropSimTradePayload
                            {
                                ProviderTradeId = parts[0],
                                AccountName = parts[1],
                                Instrument = parts[2],
                                Direction = parts[3],
                                EntryPrice = double.Parse(parts[4]),
                                ExitPrice = double.Parse(parts[5]),
                                Contracts = double.Parse(parts[6]),
                                PnL = double.Parse(parts[7]),
                                EntryTime = new DateTime(long.Parse(parts[8])),
                                ExitTime = new DateTime(long.Parse(parts[9]))
                            });
                        }
                    }
                }
            }
            catch { }
        }

        private class PositionState
        {
            public MarketPosition MarketPosition { get; set; }
            public int Quantity { get; set; }
            public double AverageEntryPrice { get; set; }
            public string Direction { get; set; }
            public DateTime EntryTime { get; set; }
        }
    }
}
