using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using NinjaTrader.NinjaScript;

namespace NinjaTrader.Custom.AddOns.PropSim
{
    public class PropSimApiClient
    {
        private readonly HttpClient _httpClient;
        // Defaulting to localhost for development, but in production this would be https://app.propsim.com
        private readonly string _baseUrl = "http://localhost:3000"; 
        private readonly string _token;

        public PropSimApiClient(string token, string baseUrl = "http://localhost:3000")
        {
            _token = token;
            _baseUrl = baseUrl;
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_token}");
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
        }

        public async Task<bool> SyncTradeAsync(PropSimTradePayload payload)
        {
            try
            {
                // Simple JSON serialization without pulling in external DLLs like Newtonsoft
                // to keep the NinjaTrader addon lightweight and dependency-free.
                string jsonPayload = $@"{{
                    ""providerTradeId"": ""{payload.ProviderTradeId}"",
                    ""accountName"": ""{payload.AccountName}"",
                    ""instrument"": ""{payload.Instrument}"",
                    ""direction"": ""{payload.Direction}"",
                    ""entryPrice"": {payload.EntryPrice},
                    ""exitPrice"": {payload.ExitPrice},
                    ""contracts"": {payload.Contracts},
                    ""pnl"": {payload.PnL},
                    ""entryTime"": ""{payload.EntryTime:O}"",
                    ""exitTime"": ""{payload.ExitTime:O}""
                }}";

                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                
                string endpoint = $"{_baseUrl}/api/integrations/ninjatrader/sync";
                HttpResponseMessage response = await _httpClient.PostAsync(endpoint, content);

                if (response.IsSuccessStatusCode)
                {
                    NinjaTrader.Code.Output.Process("PROPSIM: Trade synced successfully.", PrintTo.OutputTab1);
                    try { System.Media.SystemSounds.Beep.Play(); } catch { }
                    return true;
                }
                else
                {
                    string error = await response.Content.ReadAsStringAsync();
                    NinjaTrader.Code.Output.Process($"PROPSIM Sync Error: {response.StatusCode} - {error}", PrintTo.OutputTab1);
                    return false;
                }
            }
            catch (Exception ex)
            {
                NinjaTrader.Code.Output.Process($"PROPSIM Exception: {ex.Message}", PrintTo.OutputTab1);
                return false;
            }
        }

        public async Task<bool> SyncAccountsAsync(System.Collections.Generic.IEnumerable<string> accounts)
        {
            try
            {
                var names = string.Join(",", System.Linq.Enumerable.Select(accounts, a => $"\"{a}\""));
                string jsonPayload = $@"{{ ""accounts"": [{names}] }}";
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                
                string endpoint = $"{_baseUrl}/api/integrations/ninjatrader/accounts";
                HttpResponseMessage response = await _httpClient.PostAsync(endpoint, content);

                if (response.IsSuccessStatusCode)
                {
                    NinjaTrader.Code.Output.Process("PROPSIM: Found and synced local broker accounts.", PrintTo.OutputTab1);
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public async Task SendHeartbeatAsync()
        {
            try
            {
                var content = new StringContent("{}", Encoding.UTF8, "application/json");
                await _httpClient.PostAsync($"{_baseUrl}/api/integrations/ninjatrader/heartbeat", content);
            }
            catch { }
        }

        public async Task<bool> SyncTradesBulkAsync(System.Collections.Generic.IEnumerable<PropSimTradePayload> trades)
        {
            try
            {
                var jsonObjects = System.Linq.Enumerable.Select(trades, t => $@"{{
                    ""providerTradeId"": ""{t.ProviderTradeId}"",
                    ""accountName"": ""{t.AccountName}"",
                    ""instrument"": ""{t.Instrument}"",
                    ""direction"": ""{t.Direction}"",
                    ""entryPrice"": {t.EntryPrice},
                    ""exitPrice"": {t.ExitPrice},
                    ""contracts"": {t.Contracts},
                    ""pnl"": {t.PnL},
                    ""entryTime"": ""{t.EntryTime:O}"",
                    ""exitTime"": ""{t.ExitTime:O}""
                }}");
                
                string jsonPayload = "[" + string.Join(",", jsonObjects) + "]";
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                string endpoint = $"{_baseUrl}/api/integrations/ninjatrader/sync";
                HttpResponseMessage response = await _httpClient.PostAsync(endpoint, content);

                if (response.IsSuccessStatusCode)
                {
                    NinjaTrader.Code.Output.Process($"PROPSIM: Synced {System.Linq.Enumerable.Count(trades)} trade(s) successfully.", PrintTo.OutputTab1);
                    try { System.Media.SystemSounds.Beep.Play(); } catch { }
                    return true;
                }
                else
                {
                    string error = await response.Content.ReadAsStringAsync();
                    NinjaTrader.Code.Output.Process($"PROPSIM Sync Error: {response.StatusCode} - {error}", PrintTo.OutputTab1);
                    return false;
                }
            }
            catch (Exception ex)
            {
                NinjaTrader.Code.Output.Process($"PROPSIM Exception: {ex.Message}", PrintTo.OutputTab1);
                return false;
            }
        }
    }

    public class PropSimTradePayload
    {
        public string ProviderTradeId { get; set; }
        public string AccountName { get; set; }
        public string Instrument { get; set; }
        public string Direction { get; set; }
        public double EntryPrice { get; set; }
        public double ExitPrice { get; set; }
        public double Contracts { get; set; }
        public double PnL { get; set; }
        public DateTime EntryTime { get; set; }
        public DateTime ExitTime { get; set; }
    }
}
